import hashlib
salt = "dysjk6n9x052buzl"
i = True

#Updating textfiles after an item is selected
def updateItems(inventory, x, y, z):
    inventory.update(x)
    inventory.update(y)
    inventory.update(z)

#Read textfiles to make TotalInventory
def SetInventory(File, Inventory):
  a=open(File, "r")
  temp = {}
  Lines = a.readlines()
  for Line in Lines:
        x = Line.split(", ")
        temp.update({x[0]:x[1]})
  print(temp)
  return temp

#Deleting item requested
def updateInventory(file, itemwanted, dictionary):
   a = open(file, "r")
   Lines = a.readlines()
   a.close()
   temp = ""
   for line in Lines:
       if itemwanted not in line:
           temp += line
   a = open(file, "w+")
   a.write(temp)
   a.close()
   dictionary=SetInventory(file, dictionary)
   updateItems(inventory, SoccerStore, ClothingStore, ShoeStore)

#Purchase desired item from selected store
def buy(inventory, file):
    itemwanted = input("\n""Select item: ")
    if (itemwanted in inventory):
        name = input("\n""Enter full name: ")
        address = input("\n""Enter Address: ")
        CreditCard = input("\n""Enter Credit Card Information: ")
      
        #Hashing Credit card numbers
        HashCreditCard = CreditCard.encode()
        x = hashlib.pbkdf2_hmac('sha256', HashCreditCard, bytes(salt, "ascii"), 100000)
        
        updateInventory(file, itemwanted, inventory)
    else:
        print("\n""No items match your search. You will be redirected to the main page in a few seconds.")

inventory = {}
SoccerStore = {}
ClothingStore = {}
ShoeStore = {}

#Sets inventories for searching items
SoccerStore = SetInventory("Soccer Store.txt", SoccerStore)
ClothingStore = SetInventory("Clothing Store.txt", ClothingStore)
ShoeStore = SetInventory("Shoe Store.txt", ShoeStore)

#Allows to select specific store or quit/exit from selection
while i == True:
  print("\n""Hello, and welcome to my Online Store! We sell a variety of products for your daily needs. Come check out either our Soccer Store, Clothing Store, or Shoe Store. Select Exit to exit out of the website.")
  
  RequestedStore = input("\n""Select Store: ")
  
  if (RequestedStore == "Soccer Store") or (RequestedStore == "soccer store"):
      print(SoccerStore)
      buy(SoccerStore, "Soccer Store.txt")
  
  elif(RequestedStore == "Clothing Store") or (RequestedStore == "clothing store"):
          print(ClothingStore)
          buy(ClothingStore, "Clothing Store.txt")
      
  elif(RequestedStore == "Shoe Store") or (RequestedStore == "shoe store"):
              print(ShoeStore)
              buy(ShoeStore, "Shoe Store.txt")
  elif(RequestedStore == "Exit"):
    i = False
  else:
    print("\n""No stores match your search. You will be redirected to the main page in a few seconds.")